# aws-python
Python3 for AWS : This is a python code snipt which I created to do some operation on AWS.
 - AMI
 - SNAPSHOTS
